function showMessage() {
  alert("IRAM Public School is committed to excellence in education. Visit us to learn more!");
}

function submitForm(event) {
  event.preventDefault();
  alert("Thank you for submitting the admission form. We'll get in touch soon!");
}

// Animated counters
function animateCounter(id, target) {
  let count = 0;
  const speed = 50;
  const element = document.getElementById(id);
  const interval = setInterval(() => {
    count++;
    element.textContent = count;
    if (count >= target) clearInterval(interval);
  }, speed);
}

window.onload = () => {
  animateCounter("students", 450);
  animateCounter("teachers", 25);
  animateCounter("years", 12);
};
function loginStudent(event) {
  event.preventDefault();
  alert("Login feature is under development. Stay tuned!");
}
function loginTeacher(event) {
  event.preventDefault();
  alert("Login feature is under development. Stay tuned!");
}
function loginStudent(event) {
  event.preventDefault();
  const id = document.getElementById("student-id").value;
  const password = document.getElementById("student-password").value;

  // Simple mock check
  if (id === "student123" && password === "password") {
    document.getElementById("login-form").style.display = "none";
    document.getElementById("dashboard").style.display = "block";
  } else {
    alert("Invalid credentials. Try student123 / password");
  }
}
function loginTeacher(event) {
  event.preventDefault();
  const id = document.getElementById("teacher-id").value;
  const password = document.getElementById("teacher-password").value;

  // Simple mock check
  if (id === "teacher123" && password === "password") {
    document.getElementById("login-form").style.display = "none";
    document.getElementById("dashboard").style.display = "block";
  } else {
    alert("Invalid credentials. Try teacher123 / password");
  }
}function loginUser(event) {
  event.preventDefault();
  const id = document.getElementById("user-id").value;
  const password = document.getElementById("user-password").value;
  const role = document.getElementById("user-role").value;

  const users = {
    student123: { password: "password", role: "student" },
    admin123: { password: "password", role: "admin" }
  };

  if (users[id] && users[id].password === password && users[id].role === role) {
    localStorage.setItem("loggedInUser", JSON.stringify({ id, role }));
    showDashboard(role);
  } else {
    alert("Invalid credentials or role.");
  }
}

function showDashboard(role) {
  document.getElementById("login-form").style.display = "none";
  const dashboard = document.getElementById("dashboard");
  dashboard.style.display = "block";

  if (role === "student") {
    dashboard.innerHTML = `
      <h3>Welcome, Student!</h3>
      <div class="dashboard-grid">
        <div class="dashboard-card"><h4>📚 Grades</h4><p>Math: A | Science: B+</p></div>
        <div class="dashboard-card"><h4>📅 Attendance</h4><p>Present: 92 | Absent: 8</p></div>
        <div class="dashboard-card"><h4>💬 Messages</h4><p>"Meeting on Friday at 10 AM."</p></div>
      </div>
      <button onclick="logout()">Logout</button>
    `;
  } else if (role === "admin") {
    dashboard.innerHTML = `
      <h3>Welcome, Admin!</h3>
      <div class="dashboard-grid">
        <div class="dashboard-card"><h4>👥 Manage Students</h4><p>View, edit, or remove student records.</p></div>
        <div class="dashboard-card"><h4>📊 Reports</h4><p>Generate performance and attendance reports.</p></div>
        <div class="dashboard-card"><h4>⚙️ Settings</h4><p>Configure portal settings.</p></div>
      </div>
      <button onclick="logout()">Logout</button>
    `;
  }
}

function logout() {
  localStorage.removeItem("loggedInUser");
  location.reload();
}

// Auto-login if session exists
window.onload = () => {
  const user = JSON.parse(localStorage.getItem("loggedInUser"));
  if (user) showDashboard(user.role);
};
function toggleLoginForm() {
  const loginForm = document.getElementById("login-form");
  if (loginForm.style.display === "none" || loginForm.style.display === "") {
    loginForm.style.display = "block";
  } else {
    loginForm.style.display = "none";
  }
}
